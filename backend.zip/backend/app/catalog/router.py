from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.catalog.service import CatalogService
from datetime import date
from typing import Optional


router = APIRouter(
    prefix="/produtos",
    tags=["Catálogo"]
)


@router.get("/")
async def list_products(
    categoria_id: Optional[int] = None,
    faixa_etaria: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: AsyncSession = Depends(get_db)
):
    service = CatalogService(db)

    return await service.get_products(
        categoria_id=categoria_id,
        faixa_etaria=faixa_etaria,
        start_date=start_date,
        end_date=end_date
    )


@router.get("/categorias")
async def list_categories(
    db: AsyncSession = Depends(get_db)
):
    service = CatalogService(db)
    return await service.get_categories()


@router.get("/{product_id}")
async def get_product(
    product_id: int,
    db: AsyncSession = Depends(get_db)
):
    service = CatalogService(db)
    return await service.get_product_by_id(product_id)